import java.util.*;
import java.io.*;

// -------------------------------------------------------------------------
/**
 * This class performs many operations. It puts n-word phrases into BST's, it
 * creates and array of FileClass, it compares trees, and it makes a sorted
 * array of Output to catch the plagiarists!
 *
 * @author Brian
 * @version Dec 2, 2015
 */
public class Sequences
{
    private String route;
    private int    n;
    private int    threshold;


    // ----------------------------------------------------------
    /**
     * Create a new Sequences object.
     *
     * @param route
     * @param n
     * @param threshold
     */
    public Sequences(String route, int n, int threshold)
    {
        this.route = route;
        this.n = n;
        this.threshold = threshold;

    }


    // ----------------------------------------------------------
    /**
     * iterates though a set of documents, making a new fileclass object
     * for the fileclass array (fileclass holds a BST and a Name)
     *
     * @return FileClass[] the array of BST's and File names stored in FileCLass
     */
    public ArrayList<FileClass> addToFileArray()
    {

        File folder = new File(route);
        // theArray = new FileClass[(int)(folder.length() - 1)];
        ArrayList<FileClass> array = new ArrayList<FileClass>();

        // int count = 0;

        String theName = "";

        for (File file : folder.listFiles())
        {
            BinarySearchTree<Integer> tree = new BinarySearchTree<Integer>();
            array.add(makeFCArray(tree, file.getName(), file));
            // theArray[count] = (makeFCArray(tree, theName, file));
            // System.out.println(count);
            // count++;
        }

        return array;
        // return theArray;

    }


    // ----------------------------------------------------------
    /**
     * makes the fileclass object for each iteration of for loop from previous
     * method
     *
     * @param tree
     *            the BST
     * @param name
     *            the name of the file
     * @param file
     *            the file
     * @return FileClass the fileclass to be added to the array
     */
    public FileClass makeFCArray(
        BinarySearchTree<Integer> tree,
        String name,
        File file)
    {

        FileClass answer = new FileClass(tree, name);



        // this part makes an array list with each index representing one word
        // will be used in next part to make the combo

        String line = null;

        try
        {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(file);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            ArrayList<String> al = new ArrayList<String>();

            while ((line = bufferedReader.readLine()) != null)
            {
                Scanner f = new Scanner(line);

                String part = "";
                int binaryInsertion = 0;

                while (f.hasNext())
                {

                    //holds n-word phrases
                    if (al.size() == n)
                    {
                        part = al.toString();

                        al.remove(0);
                    }
                    al.add(f.next());

                    binaryInsertion = part.hashCode();
                    answer.getTree().insert(binaryInsertion);


                }


            }
            //always close files
            bufferedReader.close();
        }

        catch (FileNotFoundException ex)
        {
            System.out.println("Unable to open file '" + file + "'");
        }
        catch (IOException ex)
        {
            System.out.println("Error reading file '" + file + "'" + ex.toString());
            // Or we could just do this:
            //ex.printStackTrace();
        }

        return answer; // the object of type FileClass to be added to the
                       // FileClass array

    }


    // ----------------------------------------------------------
    /**
     * Compares the trees in the FileClass array and makes an array of Output
     * for the FileClass index's that had BST's with over a threshold of
     * similarities
     *
     * @param array
     *            the FileClass[]
     * @return ArrayList<Output> the arraylist of plagiarists
     */
    public ArrayList<Output> compareTrees(ArrayList<FileClass> array)
    {
        int number = 0;
        ArrayList<Output> list = new ArrayList<Output>(); // the list of those
                                                          // "caught"

        String name = "";

        for (int i = 0; i < array.size() - 1; i++)
        {

            for (int j = i + 1; j < array.size(); j++)
            {

                number =
                    array.get(i).getTree().compare(array.get(j).getTree().root);
                if (number > threshold)
                {

                    // if numberof similarities over threshold, add an insertion
                    // of type Output to an arraylist, holding info the the
                    // number of matches as well as the names of the files
                    // involved cheating
                    name =
                        array.get(i).getName() + "  and  " + array.get(j).getName();
                    Output insertion = new Output(name, number);
                    list.add(insertion);

                    // sort the arraylist as we go
                    for (int k = list.size() - 1; k > 0 && insertion
                        .getMatches() > (list.get(k - 1).getMatches()); k--)
                    {
                        Collections.swap(list, k, k - 1);
                    }
                }

            }
        }

        return list;
    }

}
