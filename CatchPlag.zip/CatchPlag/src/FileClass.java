
// -------------------------------------------------------------------------
/**
 *  This class holds the information for each member of the file array.
 *  There is a BST and a name
 *
 *  @author Brian
 *  @version Dec 2, 2015
 */
public class FileClass
{
    private BinarySearchTree<Integer> tree;
    private String name;

    // ----------------------------------------------------------
    /**
     * Create a new FileClass object.
     * @param nTree
     * @param realName
     */
    public FileClass(BinarySearchTree<Integer> nTree, String realName) {
        this.tree = nTree;
        this.name = realName;
    }

    //Getters and setters below

    public BinarySearchTree<Integer> getTree()
    {
        return tree;
    }
    public void setTree(BinarySearchTree<Integer> nTree)
    {
        this.tree = nTree;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
}
