
// -------------------------------------------------------------------------
/**
 *  This class holds the information for the name of the two files that
 *  have matches in common, as well as the number of matches they have
 *
 *  @author Brian
 *  @version Dec 2, 2015
 */
public class Output
{

    private String name;
    private int    matches;


    // ----------------------------------------------------------
    /**
     * Create a new Output object.
     * @param name
     * @param matches
     */
    public Output(String name, int matches)
    {
        this.name = name;
        this.matches = matches;
    }

    //Getters and setters below


    public String getName()
    {
        return name;
    }


    public void setName(String name)
    {
        this.name = name;
    }


    public int getMatches()
    {
        return matches;
    }


    public void setMatches(int matches)
    {
        this.matches = matches;
    }

}
