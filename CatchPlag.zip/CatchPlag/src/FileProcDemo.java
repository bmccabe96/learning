import java.util.*;
import java.io.*;

// -------------------------------------------------------------------------
/**
 * processes the files uses other classes and methods to print the final product
 * holds main method to run the argss
 *
 * @author Brian McCabe
 * @version Nov 12, 2015
 */
public class FileProcDemo
{

    // ----------------------------------------------------------
    /**
     * main method
     *
     * @param args
     *            args
     */
    public static void main(String[] args)
    {
        String route = args[0];
        int n;

        try
        {
            n = Integer.parseInt(args[1]);
        }
        catch (NumberFormatException ex) // make sure correct input
        {
            System.out.println("Incorrect input, must be an int");
            n = 0;
            System.exit(0);
        }

        int threshold;
        try
        {
            threshold = Integer.parseInt(args[2]); // threshold value for plag's
        }
        catch (NumberFormatException ex) // make sure correct input
        {
            System.out.println("Incorrect input, must be an int");
            threshold = 0;
            System.exit(0);

        }

        Sequences x = new Sequences(route, n, threshold);

        ArrayList<FileClass> array = new ArrayList<FileClass>();
        array = x.addToFileArray();

        // FileClass[] theArray = new FileClass[(int)(folder.length())];
        // theArray = x.addToFileArray();

        ArrayList<Output> list = new ArrayList<Output>();
        list = x.compareTrees(array);

        for (int i = 0; i < list.size(); i++)
        {
            System.out.println(list.get(i).getName());
            System.out.println(list.get(i).getMatches() + " matches!");
        }

        // System.out.println(theArray[1].getTree().findMin());

    }
}
